document.querySelector(".sidebar__open_btn").addEventListener("click", () => {
    const sidebar = document.getElementsByClassName("sidebar")[0];
    if (sidebar.classList.contains("sidebar__open")) {
        sidebar.classList.remove("sidebar__open");
        sidebar.classList.add("sidebar__close");
    } else {
        sidebar.classList.remove("sidebar__close");
        sidebar.classList.add("sidebar__open");
    }
});