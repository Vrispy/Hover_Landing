window.onload = function () {
    let scroll_video = window.addEventListener('scroll', () => {
        gsap.to('.Container_1', {duration: 2, x:1500});
        gsap.to('.Container_2__Left-Part__Video', {duration: 5, x:1000});
        gsap.to('.Container_2__Right-Part__Design', {duration: 5, x: -850});
        gsap.to('.Container_2__Right-Side__Color', {duration: 5, x: -600});
        gsap.to('.Container_3__Left-Part__Modes', {duration: 8, x: 1700});
        gsap.to('.Container_3__Right-Part', {duration: 8, x: -1000});
        gsap.to('.Container_3__Left-Part__video-pointer', {duration: 8, x: 1600})
        gsap.to('.upper_footer__right-side__video', {duration: 10, x: -900})
    })
}